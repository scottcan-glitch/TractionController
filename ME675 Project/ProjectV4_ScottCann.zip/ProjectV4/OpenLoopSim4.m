%% Open loop sim


Nsim = 2000;
% Initial Condition
x_0 = [10;0;0;10/sedan1.geometry.r_wheel;10/sedan1.geometry.r_wheel];
x_k = [x_0, NaN(Nx,Nh)];

for k = 1:Nsim
    fprintf('Loop Number %d!', k);

    % Record optimal input u* @k
    u_k(:,k) = [60; 60; deg2rad(2); 0]

    % Evolve state
    x_kp1 = full(xNext(x_k(:,k),u_k(:,k)))

    % Record
    x_k(:,k+1) = x_kp1
end

figure;
subplot(2,1,1);
plot(0:Nsim, x_k(1,:), 'r-', 'LineWidth', 2);
hold on;
plot(0:Nsim, xref_val(1)*ones(1, Nsim+1), 'b--', 'LineWidth', 1.5);
xlabel('Time Step');
ylabel('Position');
title('Position Tracking');
legend('Actual Position', 'Reference Position');
grid on;

subplot(2,1,2);
stairs(0:Nsim-1, u_k(1,:), 'g-', 'LineWidth', 2);
xlabel('Time Step');
ylabel('Control Input');
title('Control Input Over Time');
grid on;