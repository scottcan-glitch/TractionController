function car = makeCar()

car = struct();


    % Parameters
    pacejka = {'B','C','E','mu'};   %long & lat, 1-4

    geometry = {'a','b','h','t','r_wheel'};
    dynamics = {'lambda_front','I_1','I_2','I_3','I_4','B_1','B_2','B_3', ...
        'B_4', 'I_zz','m_vehicle','F_z1_static','F_z2_static','F_z3_static' ...
        'F_z4_static'};
    aero = {'rho_air','C_drag','A_frontal','A_side'};


    % Pacejka Params: Easier access to pacejka
    for i = 1:numel(pacejka)
        name = pacejka{i};
        P.pacejka.long.(name) = sym(name, [4 1], 'real');
        P.pacejka.lat.(name) = sym(name, [4 1], 'real');
    end

    % Geometry Params: Easier access to geometry params
    for i = 1:numel(geometry)
        name = geometry{i};
        % if name == 'wc'
        %     P.geometry.wc.x
        %     P.geometry.wc.y
        % end
        P.geometry.(name) = sym(name, 'real');  
    end

    % Dynamics Params: Easier access to dynamic params
    for i = 1:numel(dynamics)
        name = dynamics{i};
        P.dynamics.(name) = sym(name, 'real');  
    end




    car.pacejka.B =
    car.pacejka.C = 
    car.pacejka.E
end
end